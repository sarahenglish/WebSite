function sound1() {
  var audio1 = new Audio('frog.wav');
  audio1.play();
}
function sound2() {
  var audio2 = new Audio('close.wav');
  audio2.play();
}
function sound3() {
  var audio3 = new Audio('hand.wav');
  audio3.play();
}
function sound4() {
  var audio4 = new Audio('tweet.wav');
  audio4.play();
}